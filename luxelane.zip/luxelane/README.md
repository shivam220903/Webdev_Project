<h1>H&M E-Commerce Web Application Replica</h1>

- H & M Hennes & Mauritz AB (H&M) is a Swedish multinational retail-clothing company, known <br> for its fast-fashion clothing for men, women, teenagers, and children. 
- Used HTML, CSS, Javascript.
- Become a member, login, Products, Cart and Payments, Order Confirmation <br> pages and sorting the products are the main features.




![Screen_Recording_2022-11-04_at_2_45_08_PM_AdobeExpress](https://user-images.githubusercontent.com/116561688/199944081-99c4bf3e-4aa5-4cd5-8d8f-746c8178956b.gif)
<img width="1440" alt="Screenshot 2022-11-04 at 3 36 05 PM" src="https://user-images.githubusercontent.com/116561688/199947301-ae0791cc-403e-4ce5-961c-81a0768a8874.png">
<img width="1440" alt="Screenshot 2022-11-04 at 3 49 47 PM" src="https://user-images.githubusercontent.com/116561688/199950038-454f4b80-6999-4f0f-b3fb-debed34c42df.png">
<img width="1440" alt="Screenshot 2022-11-04 at 3 50 35 PM" src="https://user-images.githubusercontent.com/116561688/199950194-b2940c1d-5377-4287-9f41-bbb8dd3e4461.png">
<img width="1440" alt="Screenshot 2022-11-04 at 3 36 38 PM" src="https://user-images.githubusercontent.com/116561688/199950365-16bca6c7-8d14-47e6-bec5-e2fbea38dd69.png">
<img width="1440" alt="Screenshot 2022-11-04 at 3 50 47 PM" src="https://user-images.githubusercontent.com/116561688/199950451-4f5f434f-f9d4-47a7-af34-0f63df0b96ee.png">










