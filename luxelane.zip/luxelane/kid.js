var AccessoriesData = [
    {
      image_url: "https://lp2.hm.com/hmgoepprod?set=source%5B/62/d3/62d36798a1815310f465c7d32001c8141dc7f9b8.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5By%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Oversized hoodie",
      
      price: 1999,
      
    },
    {
      image_url: "https://lp2.hm.com/hmgoepprod?set=source%5B/fb/9f/fb9f94d3ddd8546f6d02119d532f1ac478733492.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5By%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Sweatshirt",
      
      price: 1499,
     
    },
    {
      image_url:"https://lp2.hm.com/hmgoepprod?set=source%5B/60/2c/602cd0cccceea51a410c330342591592837bef96.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5By%5D,hmver%5B2%5D&call=url%5Bfile:/product/main%5D",
      name: "Sequined dress",
      
      price: 2299,
     
    },
    {
      image_url:
         "https://lp2.hm.com/hmgoepprod?set=source%5B/2b/a7/2ba77183b467b5d9d00013d015ca93a8ed13df51.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5By%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Small shoulder bag",
      
      price: 1299,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/a8/59/a859bf16c97e260bdcf19d43b58dfd09453dd265.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B3%5D&call=url%5Bfile:/product/main%5D",
      name: "Cropped top",
      
      price: 999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/e5/dc/e5dc04abb4bd0d886cd43a334913362e927aa68c.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "90s Baggy High Waist Jeans",
      
      
      
      price: 2299,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/b2/db/b2db65aecf7c5c50db5853554de6f6e061c00ee7.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Strapless dress",
      
      price: 1599,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/2c/90/2c90c7be313d3a0d0c53da50acadda0a59868ef1.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Jumper",
      
      price: 2299,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/42/4d/424d20a2905c588182e95311f51d491490885be9.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Oversized printed sweatshirt",
      
      price: 2499,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/b4/78/b478770a946b92de71bf7840bf99d31792fa2bd1.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Knee-high boots",
      
      price: 5999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/67/75/67756dbdfd83f8bb832d89fd0b4dff2c45e74de5.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Backless dress ",
      
      price: 2999,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/c8/0b/c80b8ddaeeb949140dc256bdd1a0188a2aae9051.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Appliquéd puffer jacket",
      
      price: 3499,
    }, 
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/42/2b/422b57d66228bf30046876142747081c1aa7479f.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Rib-knit cardigan",
      
      price: 1999,
      
    },
    {
      image_url:"https://lp2.hm.com/hmgoepprod?set=source%5B/65/51/6551e1730fd211aab62c9e8a59d54b665ed644f8.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Off-the-shoulder lace dress",
      
      price: 2299,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/79/88/7988776e2a3ee46945d88f8aff87b40e385030b7.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Chunky boots",
      
      price: 2999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/5a/fe/5afed1073df7ed4c1cee76bb8bdeca57714256a8.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Double-breasted blazer dress",
      
      price: 2499,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/a0/68/a068a29ad992aedd58982728796761033e811f81.jpg%5D,origin%5Bdam%5D,category%5Bladies_shirtsblouses_shirts%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Oversized poplin shirt",
      
      price:1999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/1b/9b/1b9b71e599f8af6c1b1bf5d99a54f44bc84f266b.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Low-waisted cargo trousers",
      
      price: 1999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/83/b3/83b380caf294baf06b6f7a81901f42e3a1fdf5f6.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Large shoulder bag",
      
      price: 1599,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/8b/21/8b2122b87ab001590fa66d2cdedc24dea3d7dd11.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: " 90s Baggy High Jeans",
      price: 2999,
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/e6/7a/e67a0603080e59e4e9d163feae25f294fe6f67c8.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Flounced maxi dress",
      
      price: 1999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/cb/05/cb0557ace3dfb2f33d95cebe300679c1824ed5c7.jpg%5D,origin%5Bdam%5D,category%5Bladies_tops_vests%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Vest top with lace trims",
      
      price: 799,
     
    },
    {
      image_url:"https://lp2.hm.com/hmgoepprod?set=source%5B/5e/85/5e85c796a34950943c94d66e0257e9dbb3b0e3ad.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Canvas cargo trousers",
      
      price: 1599,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/59/45/5945559fa963e78804c748959b6cb899ecc65e88.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
        name: "Sweatshirt dress",
        
        price: 2299,
    
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/bf/47/bf47d9836b477e72f5cd1c00518bb960c545f4e1.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Oversized flannel shirt",
      
      price: 1499,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/1c/ad/1cad38c9aa2054633f361bcc782b68737d5df349.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: " Leather gloves",
      
      price: 2299,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/eb/20/eb20538d3c6b46e3ed99874384effa656a73254c.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Cotton pyjamas",
      
      price: 1499,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/05/d2/05d2aeef2a64dfc48f7dbf0ab2424aa0ef213649.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Boots",
      
      price: 2499,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/42/68/426851e441528021c88ef88c1ddf6bfc960729b5.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Hoodie",
      
      price: 1499,
     
    },
    {
      image_url:
      "https://lp2.hm.com/hmgoepprod?set=source%5B/73/69/7369bba4d759692a99b1d01074c0b2940ad28364.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Knee-high boots",
      
      price: 2299,
      
    },
    {
      image_url:
         "https://lp2.hm.com/hmgoepprod?set=source%5B/55/d1/55d192b9a9a4654ccd544e15b3be2c20e879ed45.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Printed hoodie",
      
      price: 1499,
      
    },
    {
      image_url:
         "https://lp2.hm.com/hmgoepprod?set=source%5B/91/be/91be0cd49e51cfcc014ab12cbee0fdf8c0fd30da.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Flared leggings",
      
      price: 799,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/6a/8b/6a8bae4cd423ebf700d7760949de332cf87bca76.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Loose Straight High Jeans",
      
      price: 2999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/5e/34/5e34960e70aef463cb7492e98c54ad5c0fc557fa.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "High-waisted leggings",
      
      price: 999,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/db/94/db94d2270d684eac5c0ed0c368256fcf35d6e0c1.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Pyjama top and bottoms",
      
      price: 1499,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/35/87/3587f458611080a5614c8f89b5c1d6c0eff95fec.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Calf-length boots",
      
      price: 4599,
     
    },
  ];
  
  
   
  
  var basketLSData = JSON.parse(localStorage.getItem("basket")) || [];
  
  document.querySelector("#filter").addEventListener("change", handle_sort);
  
  function handle_sort(){
    var sort_type = document.querySelector("#filter").value;
    
    if(sort_type=="none"){
      Display(AccessoriesData);
    }
    else if(sort_type == "asc" ){
      AccessoriesData.sort(function (a, b){
        return a.price - b.price;
      });
      // console.log(AccessoriesData);
      Display(AccessoriesData);
    }
    else if(sort_type == "dec"){
      AccessoriesData.sort(function (a,b){
        return b.price - a.price;
      });
      Display(AccessoriesData);
    }
    else{
      var filtered = AccessoriesData.filter(function (elem){
        return elem.category == sort_type;
      })
      Display(filtered);
    }
  }
      // console.log(AccessoriesData)
  
      Display(AccessoriesData);
  
  function Display(AccessoriesData){
  
      document.querySelector("#beauty_product_container").innerHTML ="";
      AccessoriesData.forEach(function(elm){
  
      var div = document.createElement("div");
      var img = document.createElement("img");
      img.style.width = "100%"
      img.setAttribute("src", elm.image_url);
      var Name = document.createElement("h3");
      Name.innerText = elm.name;
      var dollar = document.createElement("h4");
      dollar.innerText = "Rs.";
      dollar.style.display = "inline"
      var Price = document.createElement("h4");
      Price.innerText = elm.price;
      Price.style.display = "inline"
     
      var button = document.createElement("button");
      button.innerText = "Add";
      button.style.display = "block"
      button.setAttribute("id", "add_to_basket");
      button.addEventListener("click", Addtobasket);
      function Addtobasket(){
        var addedProduct = {
          image: elm.image_url,
          name: elm.name,
          price: elm.price
        }
        // console.log(elm.image_url);
        basketLSData.push(addedProduct);
        localStorage.setItem("basket", JSON.stringify(basketLSData));
        alert("Product added Successfully");
      }
      document.querySelector("#beauty_product_container").append(div);
      div.append(img, Name, dollar, Price, button);
  
  
  
    });
  }
  
  
  window.onscroll = function() {myFunction()};
  
  // Get the navbar
  var navbar = document.getElementById("navbar");
  
  // Get the offset position of the navbar
  var sticky = navbar.offsetTop;
  
  // Add the sticky class to the navbar when you reach its scroll position. Remove "sticky" when you leave the scroll position
  function myFunction() {
    if (window.pageYOffset >= sticky) {
      navbar.classList.add("sticky")
    } else {
      navbar.classList.remove("sticky");
    }
  }
  