var AccessoriesData = [
    {
      image_url: "https://lp2.hm.com/hmgoepprod?set=source%5B/ae/25/ae2527391d50d9bb1ec1eb55c23a96856a9bdb30.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5By%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Hi-top trainers",
      
      price: 2999,
      
    },
    {
      image_url: "https://lp2.hm.com/hmgoepprod?set=quality%5B79%5D%2Csource%5B%2Ffc%2Fd1%2Ffcd1b834ec98821caa5f744ff15015a6f3a38cac.jpg%5D%2Corigin%5Bdam%5D%2Ccategory%5B%5D%2Ctype%5BLOOKBOOK%5D%2Cres%5Bm%5D%2Chmver%5B1%5D&call=url[file:/product/main",
      name: "Sweatshirt",
      
      price: 1990,
     
    },
    {
      image_url:"https://lp2.hm.com/hmgoepprod?set=source%5B/f9/19/f9191a086ac429c42b1e5379787c45fff590cd68.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name:"Coat",
      
      price: 6999,
     
    },
    {
      image_url:
         "https://lp2.hm.com/hmgoepprod?set=source%5B/ec/50/ec506cd24e6506e0af701a46b60c584928401ae6.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Relaxed Fit Hoodie",
      
      price: 2299,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/50/d8/50d8eb1f6d1fa168b6afeeaf415474539d21d764.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Relaxed Fit Teddy hoodie",
      
      price: 2699,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/90/f8/90f8ff70db1c9a0c3bee27fd0707ba00060e910b.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Padded overshirt",
      
      
      
      price: 2999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=format%5Bwebp%5D%2Cquality%5B79%5D%2Csource%5B%2F95%2F30%2F95309b91b000c495dbcf7b3557617af197cf1ec3.jpg%5D%2Corigin%5Bdam%5D%2Ccategory%5B%5D%2Ctype%5BLOOKBOOK%5D%2Cres%5Bm%5D%2Chmver%5B1%5D&call=url%5Bfile%3A%2Fproduct%2Fmain%5D",
      name: "Oversized Fit hoodie",
      
      price: 2299,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/c9/96/c996448fb08a18acc72f921fa3a7131853cf5adb.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Relaxed Fit Overshirt",
      
      price: 2999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/00/f7/00f7ea696215b6ebfabb100ebdf47ce7fba5555f.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Regular Fit Waffle-knit jumper",
      
      price: 2999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/cd/84/cd846f1740531db0b8da25f541c5c2234acc3e4b.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Relaxed Fit Joggers",
      
      price: 1999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/9b/24/9b24f740ee247ba04f1fbc70a12ade2f7a5f6edd.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Relaxed Fit Sweatshirt",
      
      price: 1999,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/9c/85/9c8599ff98358e4e0823ded4655ba25960c97998.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Relaxed Fit Sweatshirt",
      
      price: 1999,
    }, 
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/ed/32/ed32be1d81812b36dda36bc3feacc0e2f27ce48a.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "V-neck cotton jumper",
      
      price: 1499,
      
    },
    {
      image_url:"https://lp2.hm.com/hmgoepprod?set=source%5B/5a/78/5a7880b13530787ce2bfd7dd2b01884b4315a753.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Cotton twill shirt",
      
      price: 1999,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=quality%5B79%5D%2Csource%5B%2F30%2F7f%2F307f3e1ff0485958df5943baff96c3ae905d3564.jpg%5D%2Corigin%5Bdam%5D%2Ccategory%5B%5D%2Ctype%5BLOOKBOOK%5D%2Cres%5Bm%5D%2Chmver%5B1%5D&call=url[file:/product/main]",
      name: "Relaxed Fit Nylon shorts",
      
      price: 699,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/ef/7c/ef7c0a8f82be9292ec83a8f821bb5e0e160a32e5.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Merino wool hat",
      
      price: 1299,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/66/5e/665ea7b6d83a523be0a2be7c6321951ed63f8cf1.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Cashmere scarf",
      
      price:3999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/29/39/2939149776a46c489ee9a20bccc2ed029caaea12.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Gloves",
      
      price: 1299,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/88/cb/88cbf58d3ac0474222e0889a437e04e7a1040c4f.jpg%5D,origin%5Bdam%5D,category%5Bmen_trousers_joggers%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Slim Fit Joggers",
      
      price: 1999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/b5/2b/b52b9f8dfa81ec7df5139716155922623f66429e.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: " Regular Fit Polo-neck jumper",
      price: 2699,
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/fa/ee/faeeb7463fb2fbb3979678d5183826a3fff591d0.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Rib-knit hat",
      
      price: 699,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/d7/5d/d75dd76f1c98aa0b93aa13037ad77194529310a4.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Leather gloves",
      
      price: 1999,
     
    },
    {
      image_url:"https://lp2.hm.com/hmgoepprod?set=source%5B/42/48/4248df131befff6e7425bbafc427c2c09d4ca377.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Regular Fit sweatshirt shorts",
      
      price: 799,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/da/57/da5795761fb10fa82c4224efdcf2ef38508d9aec.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
        name: "Relaxed Fit Sweatshirt",
        
        price: 1999,
    
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=format%5Bwebp%5D%2Cquality%5B79%5D%2Csource%5B%2F95%2F30%2F95309b91b000c495dbcf7b3557617af197cf1ec3.jpg%5D%2Corigin%5Bdam%5D%2Ccategory%5B%5D%2Ctype%5BLOOKBOOK%5D%2Cres%5Bm%5D%2Chmver%5B1%5D&call=url%5Bfile%3A%2Fproduct%2Fmain%5D",
      name: "Loose Fit 5-pocket twill trousers",
      
      price: 2299,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/98/c2/98c2b8bbc4cde14e469bad4434309e4ce1ba1969.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Jeans",
      
      price: 2699,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=format%5Bwebp%5D%2Cquality%5B79%5D%2Csource%5B%2Ff8%2F39%2Ff8394a2aa1ba0aeea2a01f9cb800002e48795519.jpg%5D%2Corigin%5Bdam%5D%2Ccategory%5B%5D%2Ctype%5BLOOKBOOK%5D%2Cres%5Bm%5D%2Chmver%5B1%5D&call=url%5Bfile%3A%2Fproduct%2Fmain%5D",
      name: "Hoodie",
      
      price: 2299,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/26/48/26485977af57a92a11cd4d9f79eb7a0f03923c7f.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Coat",
      
      price: 9999,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=format%5Bwebp%5D%2Cquality%5B79%5D%2Csource%5B%2F21%2Fc7%2F21c768699d2ad4a2aacfa792b14d97422d57d159.jpg%5D%2Corigin%5Bdam%5D%2Ccategory%5B%5D%2Ctype%5BLOOKBOOK%5D%2Cres%5Bm%5D%2Chmver%5B1%5D&call=url%5Bfile%3A%2Fproduct%2Fmain%5D",
      name: "The Oxford Shirt",
      
      price: 1499,
     
    },
    {
      image_url:
      "https://lp2.hm.com/hmgoepprod?set=source%5B/a1/95/a195eb0f85075e000478727bf9ed17ada0dc24a2.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Sweater",
      
      price: 2299,
      
    },
    {
      image_url:
         "https://lp2.hm.com/hmgoepprod?set=source%5B/ff/b4/ffb48637789d6bd6c2fcef638343a89da3d1ec84.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Shirt",
      
      price: 1499,
      
    },
    {
      image_url:
         "https://lp2.hm.com/hmgoepprod?set=quality%5B79%5D%2Csource%5B%2Fcf%2F16%2Fcf1654ca721bd79b96fd6aff814244d5cd28491f.jpg%5D%2Corigin%5Bdam%5D%2Ccategory%5B%5D%2Ctype%5BLOOKBOOK%5D%2Cres%5Bm%5D%2Chmver%5B1%5D&call=url[file:/product/main]",
      name: "Blazer",
      
      price: 5999,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/47/5b/475b80a90a245e2b0751aa98b01810d841852488.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Relaxed Fit Twill trousers",
      
      price: 2299,
     
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/d4/c9/d4c9fcd7d70e581a9dff535c09cdf80a9eaed261.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Felted wool-blend car coat",
      
      price: 5999,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/d6/58/d658463dff285d5acbdc0a83d82f3b138c60725e.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Relaxed Fit Overshirt",
      
      price: 2999,
      
    },
    {
      image_url:
        "https://lp2.hm.com/hmgoepprod?set=source%5B/27/14/27146b80d135376e457b324507840819bf179dee.jpg%5D,origin%5Bdam%5D,category%5B%5D,type%5BLOOKBOOK%5D,res%5Bz%5D,hmver%5B1%5D&call=url%5Bfile:/product/main%5D",
      name: "Oversized Fit hoodie",
      
      price: 2999,
     
    },
  ];
  
  
   
  
  var basketLSData = JSON.parse(localStorage.getItem("basket")) || [];
  
  document.querySelector("#filter").addEventListener("change", handle_sort);
  
  function handle_sort(){
    var sort_type = document.querySelector("#filter").value;
    
    if(sort_type=="none"){
      Display(AccessoriesData);
    }
    else if(sort_type == "asc" ){
      AccessoriesData.sort(function (a, b){
        return a.price - b.price;
      });
      // console.log(AccessoriesData);
      Display(AccessoriesData);
    }
    else if(sort_type == "dec"){
      AccessoriesData.sort(function (a,b){
        return b.price - a.price;
      });
      Display(AccessoriesData);
    }
    else{
      var filtered = AccessoriesData.filter(function (elem){
        return elem.category == sort_type;
      })
      Display(filtered);
    }
  }
      // console.log(AccessoriesData)
  
      Display(AccessoriesData);
  
  function Display(AccessoriesData){
  
      document.querySelector("#beauty_product_container").innerHTML ="";
      AccessoriesData.forEach(function(elm){
  
      var div = document.createElement("div");
      var img = document.createElement("img");
      img.style.width = "100%"
      img.setAttribute("src", elm.image_url);
      var Name = document.createElement("h3");
      Name.innerText = elm.name;
      var dollar = document.createElement("h4");
      dollar.innerText = "Rs.";
      dollar.style.display = "inline"
      var Price = document.createElement("h4");
      Price.innerText = elm.price;
      Price.style.display = "inline"
     
      var button = document.createElement("button");
      button.innerText = "Add";
      button.style.display = "block"
      button.setAttribute("id", "add_to_basket");
      button.addEventListener("click", Addtobasket);
      function Addtobasket(){
        var addedProduct = {
          image: elm.image_url,
          name: elm.name,
          price: elm.price
        }
        // console.log(elm.image_url);
        basketLSData.push(addedProduct);
        localStorage.setItem("basket", JSON.stringify(basketLSData));
        alert("Product added Successfully");
      }
      document.querySelector("#beauty_product_container").append(div);
      div.append(img, Name, dollar, Price, button);
  
  
  
    });
  }
  
  
  window.onscroll = function() {myFunction()};
  
  // Get the navbar
  var navbar = document.getElementById("navbar");
  
  // Get the offset position of the navbar
  var sticky = navbar.offsetTop;
  
  // Add the sticky class to the navbar when you reach its scroll position. Remove "sticky" when you leave the scroll position
  function myFunction() {
    if (window.pageYOffset >= sticky) {
      navbar.classList.add("sticky")
    } else {
      navbar.classList.remove("sticky");
    }
  }
  